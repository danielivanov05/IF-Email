from classes.field import Field
from classes.physical_obj import PhysicalObject

import numpy as np

class Environment:
    def __init__(self):
        self.physical_objects = []
        self.fields = []
        self.history = [] # Add history attribute

    def add_object(self, physical_object):
        """Adds a PhysicalObject instance to the environment."""
        # Check if physical_object is an instance of the PhysicalObject ABC
        if isinstance(physical_object, PhysicalObject):
            self.physical_objects.append(physical_object)
        else:
            print(f"Warning: {type(physical_object).__name__} is not a PhysicalObject and was not added.")

    def add_field(self, field):
        """Adds a Field instance to the environment."""
        # Check if field is an instance of the Field ABC
        if isinstance(field, Field):
            self.fields.append(field)
        else:
            print(f"Warning: {type(field).__name__} is not a Field and was not added.")

    def simulate(self, time_step):
        """Simulates the motion of physical objects in the environment for a given time step."""
        print(f"Simulating for time step: {time_step}")

        current_state = [] # List to store the state of objects at the current time step
        for physical_object in self.physical_objects:
            # Store current state (e.g., object type and position) before updating
            current_state.append({
                'object_type': type(physical_object).__name__,
                'position': np.copy(physical_object.position) # Store a copy of the position
            })

            # 1. Calculate the net force on the object
            net_force = physical_object.calculate_force(self.fields)

            # 2. Calculate the acceleration (F = ma)
            # Ensure mass is not zero to avoid division by zero
            if physical_object.mass > 0:
                acceleration = net_force / physical_object.mass
            else:
                acceleration = np.zeros_like(net_force) # No acceleration for massless objects

            # 3. Update velocity (using simple Euler integration)
            # velocity_new = velocity_old + acceleration * time_step
            physical_object.velocity += acceleration * time_step

            # 4. Update position (using simple Euler integration)
            # position_new = position_old + velocity_new * time_step
            physical_object.position += physical_object.velocity * time_step

            # Remove redundant print statements
            print(f"Object type: {type(physical_object).__name__}")
            print(f"  Initial Position: {physical_object.position - physical_object.velocity * time_step}")
            print(f"  Net Force: {net_force}")
            print(f"  Acceleration: {acceleration}")
            print(f"  New Velocity: {physical_object.velocity}")
            print(f"  New Position: {physical_object.position}")

        self.history.append(current_state) # Append the state of all objects at this time step to history

    def get_object_positions(self, obj_type):
        result = []
        # Iterate through the simulation history
        for step_data in self.history:
            # Each step_data is a list of dictionaries representing the state of objects at that time step
            for obj_state in step_data:
                # Check the object type and append its position to the corresponding list
                if obj_state['object_type'] == obj_type:
                    result.append(obj_state['position'])
        return result