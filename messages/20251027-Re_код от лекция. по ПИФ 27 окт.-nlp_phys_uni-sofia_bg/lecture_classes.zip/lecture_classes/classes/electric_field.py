from classes.field import Field

import numpy as np

class ElectricField(Field):
    def __init__(self, field_vector):
        self.__field_vector = np.array(field_vector, dtype=float)

    def get_field_value(self, position):
        """Returns a constant electric field vector."""
        return self.__field_vector