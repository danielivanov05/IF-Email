from classes.gravitational_field import GravitationalField
from classes.electric_field import ElectricField
from classes.particle import Particle

import numpy as np

# Concrete class inheriting from Particle and PhysicalObject (implicitly)
class ChargedParticle(Particle): # Inherits from Particle
    def __init__(self, mass, position, charge, velocity=[0.0, 0.0, 0.0]):
        # Call the constructor of the parent class (Particle)
        super().__init__(mass, position, velocity) # Pass position to parent
        self.__charge = charge # New attribute specific to ChargedParticle

    def get_electric_force(self, electric_field):
        # Method specific to ChargedParticle
        # Assuming electric_field is a numpy array with the same dimensions as position
        if len(self.position) != len(electric_field):
             raise ValueError("Electric field must have the same dimension as particle position")
        return self.__charge * electric_field

    def calculate_force(self, fields):
        """Calculates the net force on the charged particle from a list of fields (considering gravitational and electric)."""
        net_force = np.zeros_like(self.position)
        for field in fields:
            if isinstance(field, GravitationalField):
                # Gravitational force = mass * gravitational field vector
                net_force += self.mass * field.get_field_value(self.position) # Use position
            elif isinstance(field, ElectricField):
                # Electric force = charge * electric field vector at particle's position
                net_force += self.__charge * field.get_field_value(self.position) # Use position
        return net_force
