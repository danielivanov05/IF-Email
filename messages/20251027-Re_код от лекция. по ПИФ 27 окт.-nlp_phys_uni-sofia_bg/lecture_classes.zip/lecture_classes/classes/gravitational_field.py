from classes.field import Field

import numpy as np

class GravitationalField(Field):
    def __init__(self, gravity_vector=[0.0, -9.8, 0.0]):
        self.__gravity_vector = np.array(gravity_vector, dtype=float)

    def get_field_value(self, position):
        """Returns a constant gravitational field vector."""
        return self.__gravity_vector