from classes.gravitational_field import GravitationalField
from classes.physical_obj import PhysicalObject
import numpy as np

# Concrete class inheriting from PhysicalObject
class Particle(PhysicalObject): # Inheriting from PhysicalObject is implied for the task context
    def __init__(self, mass, position, velocity=[0.0, 0.0, 0.0]):
        self.mass = mass
        self.position = np.array(position, dtype=float) # Added position
        self.velocity = np.array(velocity, dtype=float)
        self.acceleration = np.zeros_like(self.position)

    def set_velocity(self, velocity):
        self.velocity = np.array(velocity, dtype=float)

    def get_kinetic_energy(self):
        # method: calculates kinetic energy
        return 0.5 * self.mass * np.sum(self.velocity**2)

    def apply_force(self, force):
        # method: applies a force and calculates acceleration (simple particle only considers net force)
        self.acceleration = force / self.mass
        print(f"Applied force {force} to Particle. New acceleration: {self.acceleration}")

    def calculate_momentum(self):
        # Implementation for a Particle (assuming this method exists from previous steps)
        return self.mass * self.velocity

    def calculate_force(self, fields):
        net_force = np.zeros_like(self.position)
        for field in fields:
            if isinstance(field, GravitationalField):
                net_force += self.mass * field.get_field_value(self.position)
        return net_force