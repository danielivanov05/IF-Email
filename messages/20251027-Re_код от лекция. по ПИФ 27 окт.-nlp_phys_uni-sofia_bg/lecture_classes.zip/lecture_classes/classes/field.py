from abc import ABC, abstractmethod

class Field(ABC):
    @abstractmethod
    def get_field_value(self, position):
        """Abstract method to get the field value at a given position."""
        pass