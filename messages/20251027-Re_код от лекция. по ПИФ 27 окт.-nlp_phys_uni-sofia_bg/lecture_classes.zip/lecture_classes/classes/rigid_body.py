from classes.physical_obj import PhysicalObject
import numpy as np

# Concrete class inheriting from PhysicalObject
class RigidBody(PhysicalObject):
    def __init__(self, mass, center_of_mass_velocity, moment_of_inertia, angular_velocity):
        self.mass = mass
        self.center_of_mass_velocity = np.array(center_of_mass_velocity, dtype=float)
        self.moment_of_inertia = moment_of_inertia # Assuming scalar for simplicity
        self.angular_velocity = np.array(angular_velocity, dtype=float)

    def calculate_momentum(self):
        # Implementation for a RigidBody (linear momentum)
        return self.mass * self.center_of_mass_velocity

    def calculate_angular_momentum(self):
        # RigidBody can have additional methods
        return self.moment_of_inertia * self.angular_velocity
