from abc import ABC, abstractmethod

# Define an abstract base class
class PhysicalObject(ABC):
    @abstractmethod
    def calculate_momentum(self):
        """Abstract method to calculate momentum."""
        pass