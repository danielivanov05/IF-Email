#
#  Classes, inheritance, encapsulation, polymorphism, abstraction
#

from classes.particle import Particle
from classes.physical_obj import PhysicalObject
from classes.rigid_body import RigidBody

import numpy as np

# Create instances of the concrete classes
particle = Particle(mass=1.0, velocity=[5, 0, 0], position=[0., 0., 0.])
# For simplicity, let's create a rigid body with only linear motion for momentum example
rigid_body = RigidBody(mass=10.0, center_of_mass_velocity=[2, 0, 0], moment_of_inertia=5.0, angular_velocity=[0,0,0])


# Calculate and print the momentum using the abstract method call
print(f"Momentum of the particle: {particle.calculate_momentum()}")
print(f"Momentum of the rigid body: {rigid_body.calculate_momentum()}")

# Demonstrate a method specific to RigidBody
print(f"Angular momentum of the rigid body: {rigid_body.calculate_angular_momentum()}")

# Trying to instantiate the abstract class will raise an error
try:
    abstract_object = PhysicalObject()
except TypeError as e:
    print(f"\nCannot instantiate abstract class: {e}")


# Example of Fields

from classes.electric_field import ElectricField
from classes.gravitational_field import GravitationalField

electric_field_instance = ElectricField(field_vector=[10.0, 0.0, 0.0])
gravitational_field_instance = GravitationalField()

position = np.array([1.0, 2.0, 3.0], dtype=float)

print(f"Electric field at {position}: {electric_field_instance.get_field_value(position)}")
print(f"Gravitational field at {position}: {gravitational_field_instance.get_field_value(position)}")


# more complicated example - Universe

from classes.environment import Environment
from classes.charged_particle import ChargedParticle

# Simulate for a sufficient number of time steps
num_steps = 100 # Choose a suitable number of steps
time_step = 0.05 # Choose a suitable time step

print(f"Starting simulation for {num_steps} steps with time step {time_step}")

# Create a new environment and objects to ensure clean history
universe = Environment()

# Create some fields
grav_field = GravitationalField(gravity_vector=[0.0, -9.8, 0.0])
elec_field = ElectricField(field_vector=[100.0, 0.0, 0.0])

# Create some physical objects with initial conditions
particle = Particle(mass=2.0, position=[0.0, 0.0, 0.0], velocity=[10.0, 20.0, 0.0]) # Increased initial velocity for better trajectory
charged_particle = ChargedParticle(mass=1.0, position=[0.0, 0.0, 0.0], charge=-1.0, velocity=[-5.0, 15.0, 0.0]) # Increased initial velocity

# Add them to the environment
universe.add_field(grav_field)
universe.add_field(elec_field)
universe.add_object(particle)
universe.add_object(charged_particle)


for i in range(num_steps):
    universe.simulate(time_step)

print("Simulation finished.")

# get particle positions
particle_positions = np.array(universe.get_object_positions('Particle'))
charged_particle_positions = np.array(universe.get_object_positions('ChargedParticle'))


import matplotlib.pyplot as plt

# Create a new figure and a 3D subplot
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# Plot the trajectory of the simple particle
ax.plot(particle_positions[:, 0], particle_positions[:, 1], particle_positions[:, 2], label='Particle Trajectory', color='blue')

# Plot the trajectory of the charged particle
ax.plot(charged_particle_positions[:, 0], charged_particle_positions[:, 1], charged_particle_positions[:, 2], label='Charged Particle Trajectory', color='red')

# Add labels and title
ax.set_xlabel('X Position')
ax.set_ylabel('Y Position')
ax.set_zlabel('Z Position')
ax.set_title('Particle Trajectories in Fields')

# Add a legend
ax.legend()

# Show the plot
plt.show()